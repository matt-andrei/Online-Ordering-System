import  {useState, createContext, useContext, useEffect} from 'react';


const AuthContext = createContext();

export default function AuthProvider({children}) {

    const [user, setUser] = useState(null);
    const [ loading, setLoading] = useState(false);
    const [ error, setError] = useState(null);

    const login = (credentials) => {
        setLoading(true);
        setError(null); // Clear previous errors
        // Simulating backend authentication
        if (credentials.username === 'admin' && credentials.password === '123') {
            const userData = {id: 1, username: username, name: "Mr. Admin"}; // Simulated user data, imagine this is coming from a backend
            setUser(userData); // Set user state
            return true;
        }else{
            setError("Invalid Credentials")
        }
        setLoading(false);
        return false;
    };

    const logout = () => {
        setLoading(false);
        setUser(null); // Clear user
        
        localStorage.removeItem('isAuthenticated'); // Clear authentication status from localStorage
    };

  return (
    <AuthContext.Provider value={{user, error, loading, login, logout}}>
        {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext);
