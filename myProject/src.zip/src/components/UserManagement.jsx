import React, { useState } from "react";

export default function UserManagement() {
  // Simulated users
  const users = [
    {
      uid: "202501",
      name: "Sample User",
      username: "SampleUser",
      password: "pass1",
      userrole: "Pharmacy Staff",
    },
    {
      uid: "202502",
      name: "Another User",
      username: "User1",
      password: "pass2",
      userrole: "Customer",
    },
    {
      uid: "202503",
      name: "Last User",
      username: "User2",
      password: "pass3",
      userrole: "Customer",
    },
  ];

  const [searchRole, setSearchRole] = useState("");
  // Search Filter
  const filteredUsers = searchRole
    ? users.filter((user) => user.userrole === searchRole)
    : users;

  return (
    <div className="p-6 flex-1">
      {/* Title */}
      <div className="flex justify-between mb-6">
        <h1 className="text-3xl font-bold mb-4">User Management</h1>
        <button className="bg-teal-500 text-white px-4 py-2 rounded-lg hover:bg-teal-600">
          Add User
        </button>
      </div>

      {/* Card Container */}
      <div className="bg-white shadow-[0_3px_10px_rgb(0,0,0,0.2)] rounded-lg p-6">
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">User</h2>
          <select
            className="border px-4 py-2 rounded-lg"
            onChange={(e) => setSearchRole(e.target.value)}
            value={searchRole}
          >
            <option value="">All</option>
            <option value="Pharmacy Staff">Pharmacy Staff</option>
            <option value="Customer">Customer</option>
          </select>
        </div>

        {/* User Table */}
        <div className="overflow-x-auto">
          <table className="w-full border-collapse rounded-lg overflow-hidden">
            <thead>
              <tr className="bg-gray-200 text-gray-700">
                <th className="py-3 px-4 text-left">UID</th>
                <th className="py-3 px-4 text-left">Name</th>
                <th className="py-3 px-4 text-left">User Role</th>
                <th className="py-3 px-4 text-left">Username</th>
                <th className="py-3 px-4 text-left">Password</th>
                <th className="py-3 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user, index) => (
                <tr key={index} className="border-t">
                  <td className="py-3 px-4">{user.uid}</td>
                  <td className="py-3 px-4">{user.name}</td>
                  <td className="py-3 px-4">{user.userrole}</td>
                  <td className="py-3 px-4">{user.username}</td>
                  <td className="py-3 px-4">{user.password}</td>
                  <td className="py-3 px-4">
                    <button className="bg-blue-500 text-white px-3 py-1 rounded-md hover:bg-blue-600">
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
