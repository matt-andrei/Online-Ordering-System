import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function NavBar() {
  const { logout } = useAuth();

  return (
    <div className="h-screen w-64 bg-gray-100 p-5 flex flex-col fixed left-0 top-0">
      {/* Profile Icon */}
      <div className="flex flex-col items-center mb-3">
        <div className="w-16 h-16 bg-teal-600 rounded-full flex items-center justify-center"></div>
        <span className="text-sm text-gray-600 mt-2">Admin</span>
      </div>

      {/* Navigation Links */}
      <div className="flex flex-col gap-y-3 text-gray-700 flex-grow">
        <span className="font-semibold text-gray-500 text-sm">Controls</span>
        <Link to="/dashboard" className="p-2 rounded hover:bg-gray-200">
          Dashboard
        </Link>
        <Link to="/user" className="p-2 rounded hover:bg-gray-200">
          User Management
        </Link>
        <Link to="/prescriptions" className="p-2 rounded hover:bg-gray-200">
          Prescription Verification
        </Link>{/*/still empty */}
        <Link to="/products" className="p-2 rounded hover:bg-gray-200">
          Product Management
        </Link>{/*/still empty */}
        <Link to="/inventory" className="p-2 rounded hover:bg-gray-200">
          Inventory Management
        </Link>{/*/still empty */}
        <Link to="/reports" className="p-2 rounded hover:bg-gray-200">
          Reports
        </Link>{/*/still empty */}
      </div>

      {/* Logout */}
      <div className="mt-auto">
        <span className="font-semibold text-gray-500 text-sm">Settings</span>
        <button
          onClick={logout}
          className="w-full text-left p-2 text-red-600 font-semibold hover:bg-gray-200 rounded"
        >
          Logout
        </button>
      </div>
    </div>
  );
}
