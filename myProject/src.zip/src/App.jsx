import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import { useAuth } from './context/AuthContext';
import UserPage from './pages/UserPage';

const PrivateRoute = ({ element }) => {
  const { user } = useAuth();
  return user ? element : <Navigate to="/" />;
};


function App() {
  return (
    <>
      <Router>
        <Routes>
          {/* Routes go here👇🏽 */}
          <Route path="/" element={<LoginPage />} />
          {/* private routes go here👇🏽 (need authentication)👆🏽*/}
          <Route path="/dashboard" element={<PrivateRoute element={<DashboardPage />}/>}/>
          <Route path="/user" element={<PrivateRoute element={<UserPage />}/>}/>
        </Routes>
      </Router>
    </>
  )
}

export default App
