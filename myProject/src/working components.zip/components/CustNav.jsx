import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import { ShoppingCart, LogOut, Search, Home, Menu } from "lucide-react";

const CustNav = ({ onSearch, cartItemsCount, onCartClick }) => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [currentSection, setCurrentSection] = useState("home");
  const [searchQuery, setSearchQuery] = useState("");

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const handleSearch = (e) => {
    const value = e.target.value;
    setSearchQuery(value);
    if (onSearch) {
      onSearch(value);
    }
  };

  return (
    <>
      {/* Top Navigation Bar */}
      <nav className="fixed top-0 left-0 w-full bg-white z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <button
              className="p-2 rounded-full hover:bg-gray-100 transition-colors duration-200"
              onClick={handleLogout}
              aria-label="Logout"
            >
              <LogOut className="h-6 w-6 text-gray-600" />
            </button>

            <div className="flex-1 max-w-2xl mx-4">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search Product..."
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-full bg-gray-50 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  value={searchQuery}
                  onChange={handleSearch}
                />
              </div>
            </div>

            {/* Cart Button */}
            <button
              className="p-2 relative rounded-full hover:bg-gray-100 transition-colors duration-200"
              onClick={onCartClick}
              aria-label="Cart"
            >
              <ShoppingCart className="h-6 w-6 text-gray-600" />
              <span className="absolute -top-1 -right-1 bg-blue-600 text-white text-xs min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center font-semibold">
                {cartItemsCount || 0}
              </span>
            </button>
          </div>
        </div>
      </nav>

      {/* Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 w-full bg-white shadow-md z-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-around items-center h-16">
            <button
              className={`flex flex-col items-center gap-1 transition-colors duration-200 ${
                currentSection === "home" ? "text-blue-600" : "text-gray-600"
              }`}
              onClick={() => {
                setCurrentSection("home");
                navigate("/");
              }}
              aria-label="Home"
            >
              <Home className="h-6 w-6" />
              <span className="text-xs font-medium">Home</span>
            </button>
            <button
              className={`flex flex-col items-center gap-1 transition-colors duration-200 ${
                currentSection === "categories"
                  ? "text-blue-600"
                  : "text-gray-600"
              }`}
              onClick={() => {
                setCurrentSection("categories");
              }}
              aria-label="Categories"
            >
              <Menu className="h-6 w-6" />
              <span className="text-xs font-medium">Categories</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Spacer for bottom nav */}
      <div className="h-16"></div>
    </>
  );
};

export default CustNav;
