import React, { useEffect, useState } from "react";
import axios from "axios";
import InventoryModal from "./InventoryModal";
import { toast } from "react-toastify";

function InventoryManagement() {
  const [batches, setBatches] = useState([]);
  const [products, setProducts] = useState([]);
  const [productStats, setProductStats] = useState({});
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchBatches = async () => {
    try {
      const response = await axios.get("http://127.0.0.1:8000/api/batches/");
      setBatches(response.data);
    } catch (error) {
      console.error("Error fetching batches:", error);
      setError("Failed to fetch batches. Please try again.");
    }
  };

  const fetchProducts = async () => {
    try {
      const response = await axios.get("http://127.0.0.1:8000/api/products/");
      setProducts(response.data);
    } catch (error) {
      console.error("Error fetching products:", error);
      setError("Failed to fetch products. Please try again.");
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        await Promise.all([fetchBatches(), fetchProducts()]);
      } catch (error) {
        setError("Failed to load inventory data. Please try again.");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    const stats = {};
    products.forEach((product) => {
      const id = product.id;
      const productBatches = batches.filter((batch) => batch.product.id === id);

      stats[id] = {
        productId: id,
        productName: product.product_name,
        totalStockIn: productBatches.reduce(
          (sum, batch) => sum + batch.quantity,
          0
        ),
        totalExpired: productBatches.reduce(
          (sum, batch) => sum + (batch.is_expired ? batch.quantity : 0),
          0
        ),
        totalStock: product.total_stock,
        isLowStock: product.is_low_stock,
        isOutOfStock: product.is_out_of_stock,
        stockOut: productBatches.reduce(
          (sum, batch) => sum + batch.stock_out,
          0
        ),
        available: product.total_stock,
        batches: productBatches,
      };
    });

    setProductStats(stats);
  }, [batches, products]);

  const getStockStatus = (stats) => {
    if (stats.totalExpired > 0) {
      return {
        label: "Has Expired Items",
        bg: "bg-red-100",
        text: "text-red-800",
      };
    } else if (stats.isOutOfStock) {
      return {
        label: "Out of Stock",
        bg: "bg-red-100",
        text: "text-red-800",
      };
    } else if (stats.isLowStock) {
      return {
        label: "Low Stock",
        bg: "bg-yellow-100",
        text: "text-yellow-800",
      };
    }
    return {
      label: "In Stock",
      bg: "bg-green-100",
      text: "text-green-800",
      icon: null,
    };
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
        {error}
      </div>
    );
  }

  return (
    <div className="p-6 flex-1">
      <div className="flex justify-between mb-6">
        <h1 className="text-3xl font-bold mb-4">Inventory Management</h1>
      </div>

      <div className="bg-white shadow-[0_3px_10px_rgb(0,0,0,0.2)] rounded-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Inventory</h2>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse rounded-lg">
            <thead>
              <tr className="bg-gray-200 text-gray-700">
                <th className="py-3 px-4 text-left">Product ID</th>
                <th className="py-3 px-4 text-left">Product Name</th>
                <th className="py-3 px-4 text-left">Total Stock</th>
                <th className="py-3 px-4 text-left">Stock Out</th>
                <th className="py-3 px-4 text-left">Available</th>
                <th className="py-3 px-4 text-left">Status</th>
                <th className="py-3 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((prod) => {
                const stats = productStats[prod.id] || {
                  totalStockIn: 0,
                  totalExpired: 0,
                  stockOut: 0,
                  totalStock: prod.total_stock,
                  productName: prod.product_name,
                  isLowStock: false,
                  isOutOfStock: false,
                  available: 0,
                };

                const stockStatus = getStockStatus(stats);

                return (
                  <tr key={prod.id} className="border-t hover:bg-gray-50">
                    <td className="py-3 px-4">{prod.id}</td>
                    <td className="py-3 px-4">{stats.productName}</td>
                    <td className="py-3 px-4">{stats.totalStockIn}</td>
                    <td className="py-3 px-4">{stats.stockOut}</td>
                    <td className="py-3 px-4">{stats.available}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-1 rounded-full text-sm font-semibold ${stockStatus.bg} ${stockStatus.text}`}
                      >
                        {stockStatus.icon}
                        {stockStatus.label}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <button
                        onClick={() => setSelectedProduct(prod)}
                        className="bg-blue-500 text-white px-3 py-1 rounded-md hover:bg-blue-600"
                      >
                        View Batches
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {selectedProduct && (
        <InventoryModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          refreshBatches={() => {
            fetchBatches();
            fetchProducts();
          }}
        />
      )}
    </div>
  );
}

export default InventoryManagement;
