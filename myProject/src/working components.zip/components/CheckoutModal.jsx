import React, { useState } from "react";
import { X } from "lucide-react";
import { toast } from "react-toastify";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import PropTypes from "prop-types";

const CheckoutModal = ({ isOpen, onClose, cartItems, onOrderComplete }) => {
  const [loading, setLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("COD");
  const [deliveryMethod, setDeliveryMethod] = useState("PICKUP");
  const [pickupDate, setPickupDate] = useState("");
  const [notes, setNotes] = useState("");
  const { user } = useAuth();

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user) {
      toast.error("Please login to place an order");
      return;
    }

    // Validate cart items
    const invalidItems = cartItems.filter(
      (item) => !item.batch_id || !item.quantity || !item.price
    );
    if (invalidItems.length > 0) {
      toast.error("Invalid cart items detected. Please try again.");
      return;
    }

    // Check for prescription requirements
    const requiresPrescription = cartItems.some(
      (item) => item.requires_prescription
    );
    if (requiresPrescription && paymentMethod === "ONLINE") {
      toast.error(
        "Products requiring prescription cannot be ordered with online payment"
      );
      return;
    }

    setLoading(true);

    try {
      // Prepare order data
      const orderData = {
        order_items: cartItems.map((item) => ({
          batch_id: parseInt(item.batch_id),
          quantity: parseInt(item.quantity),
          price_at_time: parseFloat(item.price),
        })),
        payment_method: paymentMethod,
        delivery_method: deliveryMethod,
        pickup_date: pickupDate,
        notes: notes || "",
      };

      // Log the order data for debugging
      console.log("Submitting order data:", orderData);

      // Submit order
      await axios.post("http://127.0.0.1:8000/api/orders/", orderData, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${user.accessToken}`,
        },
      });

      toast.success("Order placed successfully!");
      onOrderComplete();
      onClose();
    } catch (error) {
      console.error("Order submission error:", error);
      let errorMessage = "Failed to place order. Please try again.";

      if (error.response?.data) {
        const errorData = error.response.data;
        if (typeof errorData === "object") {
          if (errorData.order_items) {
            errorMessage = Array.isArray(errorData.order_items)
              ? errorData.order_items.join(", ")
              : errorData.order_items;
          } else if (errorData.error) {
            errorMessage = errorData.error;
          }
        }
      }

      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Checkout</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Payment Method */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Payment Method
            </label>
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            >
              <option value="COD">Cash on Delivery</option>
              <option value="ONLINE">Online Payment</option>
            </select>
          </div>

          {/* Delivery Method */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Delivery Method
            </label>
            <select
              value={deliveryMethod}
              onChange={(e) => setDeliveryMethod(e.target.value)}
              className="w-full p-2 border rounded-lg"
              required
            >
              <option value="PICKUP">Pickup</option>
              <option value="DELIVERY">Delivery</option>
            </select>
          </div>

          {/* Pickup Date */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Pickup Date
            </label>
            <input
              type="date"
              value={pickupDate}
              onChange={(e) => setPickupDate(e.target.value)}
              min={new Date().toISOString().split("T")[0]}
              className="w-full p-2 border rounded-lg"
              required
            />
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium mb-2">Notes</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full p-2 border rounded-lg"
              rows="3"
              placeholder="Any special instructions..."
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? "Processing..." : "Place Order"}
          </button>
        </form>
      </div>
    </div>
  );
};

CheckoutModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  cartItems: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      product_name: PropTypes.string.isRequired,
      price: PropTypes.number.isRequired,
      quantity: PropTypes.number.isRequired,
      batch_id: PropTypes.number.isRequired,
      requires_prescription: PropTypes.bool,
    })
  ).isRequired,
  onOrderComplete: PropTypes.func.isRequired,
};

export default CheckoutModal;
