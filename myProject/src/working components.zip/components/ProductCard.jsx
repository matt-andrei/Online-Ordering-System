import React, { useState } from "react";
import { ShoppingCart } from "lucide-react";
import { toast } from "react-toastify";
import { useAuth } from "../context/AuthContext";
import axios from "axios";
import PropTypes from "prop-types";

const ProductCard = ({ product, onAddToCart }) => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);

  const handleAddToCart = async () => {
    if (!user) {
      toast.error("Please login to add items to cart");
      return;
    }

    setLoading(true);
    try {
      // Fetch active batches for the product
      const response = await axios.get(
        `http://127.0.0.1:8000/api/product/${product.id}/batches/active/`
      );

      const activeBatches = response.data;
      if (!activeBatches || activeBatches.length === 0) {
        toast.error("No active batches available for this product");
        return;
      }

      // Get the first available batch
      const firstBatch = activeBatches[0];
      if (firstBatch.quantity <= 0) {
        toast.error("This product is out of stock");
        return;
      }

      // Add product to cart with batch information
      onAddToCart({
        id: product.id,
        product_name: product.product_name,
        price: product.price,
        quantity: 1,
        batch_id: firstBatch.id,
        image: product.image,
        requires_prescription: product.requires_prescription,
      });

      toast.success(`${product.product_name} added to cart!`);
    } catch (error) {
      console.error("Error adding to cart:", error);
      toast.error("Failed to add product to cart");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      <div className="aspect-square mb-4">
        <img
          src={product.image || "/placeholder.png"}
          alt={product.product_name}
          className="w-full h-full object-contain"
        />
      </div>

      <h3 className="text-lg font-semibold mb-2">{product.product_name}</h3>
      <p className="text-gray-600 mb-2">{product.description}</p>
      <p className="text-blue-600 font-bold mb-4">₱{product.price}</p>

      <button
        onClick={handleAddToCart}
        disabled={loading}
        className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
      >
        <ShoppingCart className="inline-block mr-2" />
        {loading ? "Adding..." : "Add to Cart"}
      </button>
    </div>
  );
};

ProductCard.propTypes = {
  product: PropTypes.shape({
    id: PropTypes.number.isRequired,
    product_name: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    description: PropTypes.string,
    image: PropTypes.string,
    requires_prescription: PropTypes.bool,
  }).isRequired,
  onAddToCart: PropTypes.func.isRequired,
};

export default ProductCard;
