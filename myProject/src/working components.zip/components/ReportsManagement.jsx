import React, { useState, useEffect } from "react";
import axios from "axios";
import { FaSpinner, FaDownload, FaCalendarAlt } from "react-icons/fa";
import { DateRangePicker } from "react-date-range";
import "react-date-range/dist/styles.css";
import "react-date-range/dist/theme/default.css";
import SalesReport from "./reports/SalesReport";
import InventoryReport from "./reports/InventoryReport";
import PrescriptionReport from "./reports/PrescriptionReport";

const ReportsManagement = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [dateRange, setDateRange] = useState({
    startDate: new Date(new Date().setMonth(new Date().getMonth() - 1)),
    endDate: new Date(),
  });
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [reportType, setReportType] = useState("sales");
  const [reportData, setReportData] = useState({
    sales: {
      totalSales: 0,
      totalOrders: 0,
      averageOrderValue: 0,
      salesByDate: [],
      topProducts: [],
    },
    inventory: {
      totalProducts: 0,
      lowStockItems: 0,
      outOfStockItems: 0,
      expiringItems: 0,
      stockLevels: [],
    },
    prescriptions: {
      totalPrescriptions: 0,
      pendingVerifications: 0,
      verifiedPrescriptions: 0,
      rejectedPrescriptions: 0,
      prescriptionTrends: [],
    },
  });

  useEffect(() => {
    fetchReportData();
  }, [reportType, dateRange]);

  const fetchReportData = async () => {
    setLoading(true);
    try {
      // TODO: Replace with actual API calls when backend is ready
      // const response = await axios.get(`http://127.0.0.1:8000/api/reports/${reportType}/`, {
      //   params: {
      //     start_date: dateRange.startDate.toISOString(),
      //     end_date: dateRange.endDate.toISOString()
      //   }
      // });
      // setReportData(prev => ({
      //   ...prev,
      //   [reportType]: response.data
      // }));

      // Dummy data for testing
      const dummyData = {
        sales: {
          totalSales: 150000,
          totalOrders: 150,
          averageOrderValue: 1000,
          salesByDate: [
            { date: "2024-03-01", amount: 5000 },
            { date: "2024-03-02", amount: 7500 },
            { date: "2024-03-03", amount: 6000 },
          ],
          topProducts: [
            { name: "Paracetamol 500mg", quantity: 500, revenue: 25000 },
            { name: "Amoxicillin 250mg", quantity: 300, revenue: 15000 },
            { name: "Vitamin C 1000mg", quantity: 200, revenue: 10000 },
          ],
        },
        inventory: {
          totalProducts: 100,
          lowStockItems: 15,
          outOfStockItems: 5,
          expiringItems: 10,
          stockLevels: [
            { name: "Paracetamol 500mg", current: 50, threshold: 20 },
            { name: "Amoxicillin 250mg", current: 30, threshold: 15 },
            { name: "Vitamin C 1000mg", current: 25, threshold: 10 },
          ],
        },
        prescriptions: {
          totalPrescriptions: 200,
          pendingVerifications: 30,
          verifiedPrescriptions: 150,
          rejectedPrescriptions: 20,
          prescriptionTrends: [
            { date: "2024-03-01", count: 10 },
            { date: "2024-03-02", count: 15 },
            { date: "2024-03-03", count: 12 },
          ],
        },
      };

      setReportData((prev) => ({
        ...prev,
        [reportType]: dummyData[reportType],
      }));
    } catch (error) {
      setError("Failed to fetch report data");
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    try {
      // TODO: Implement export functionality
      // const response = await axios.get(`http://127.0.0.1:8000/api/reports/${reportType}/export/`, {
      //   params: {
      //     start_date: dateRange.startDate.toISOString(),
      //     end_date: dateRange.endDate.toISOString()
      //   },
      //   responseType: 'blob'
      // });
      // const url = window.URL.createObjectURL(new Blob([response.data]));
      // const link = document.createElement('a');
      // link.href = url;
      // link.setAttribute('download', `${reportType}_report.xlsx`);
      // document.body.appendChild(link);
      // link.click();
      // link.remove();
    } catch (error) {
      console.error("Failed to export report:", error);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <FaSpinner className="animate-spin text-4xl text-blue-500" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
        {error}
      </div>
    );
  }

  return (
    <div className="p-6 flex-1">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Reports Management</h1>
        <div className="flex gap-4">
          <div className="relative">
            <button
              onClick={() => setShowDatePicker(!showDatePicker)}
              className="bg-white px-4 py-2 rounded-md shadow flex items-center gap-2"
            >
              <FaCalendarAlt />
              {dateRange.startDate.toLocaleDateString()} -{" "}
              {dateRange.endDate.toLocaleDateString()}
            </button>
            {showDatePicker && (
              <div className="absolute right-0 mt-2 z-10">
                <DateRangePicker
                  ranges={[dateRange]}
                  onChange={(item) => setDateRange(item.selection)}
                  months={1}
                  direction="horizontal"
                />
              </div>
            )}
          </div>
          <button
            onClick={handleExport}
            className="bg-blue-500 text-white px-4 py-2 rounded-md shadow flex items-center gap-2 hover:bg-blue-600"
          >
            <FaDownload /> Export Report
          </button>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex gap-4">
          <button
            onClick={() => setReportType("sales")}
            className={`px-4 py-2 rounded-md ${
              reportType === "sales"
                ? "bg-blue-500 text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            Sales Report
          </button>
          <button
            onClick={() => setReportType("inventory")}
            className={`px-4 py-2 rounded-md ${
              reportType === "inventory"
                ? "bg-blue-500 text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            Inventory Report
          </button>
          <button
            onClick={() => setReportType("prescriptions")}
            className={`px-4 py-2 rounded-md ${
              reportType === "prescriptions"
                ? "bg-blue-500 text-white"
                : "bg-gray-200 text-gray-700 hover:bg-gray-300"
            }`}
          >
            Prescription Report
          </button>
        </div>
      </div>

      <div className="bg-white shadow-[0_3px_10px_rgb(0,0,0,0.2)] rounded-lg p-6">
        {reportType === "sales" && <SalesReport data={reportData.sales} />}
        {reportType === "inventory" && (
          <InventoryReport data={reportData.inventory} />
        )}
        {reportType === "prescriptions" && (
          <PrescriptionReport data={reportData.prescriptions} />
        )}
      </div>
    </div>
  );
};

export default ReportsManagement;
