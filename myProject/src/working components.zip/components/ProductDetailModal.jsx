import React, { useState, useEffect } from "react";
import { X } from "lucide-react";
import { toast } from "react-toastify";
import axios from "axios";

const ProductDetailModal = ({ product, onClose }) => {
  const [batches, setBatches] = useState([]);
  const [currentBatch, setCurrentBatch] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchBatches = async () => {
    try {
      const response = await axios.get(
        `http://127.0.0.1:8000/api/product/${product.id}/batches/`
      );
      const sortedBatches = response.data
        .filter((batch) => batch.is_active && !batch.is_expired)
        .sort(
          (a, b) => new Date(a.expiration_date) - new Date(b.expiration_date)
        );
      setBatches(sortedBatches);
      setCurrentBatch(sortedBatches[0] || null);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching batches:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (product) {
      fetchBatches();
    }
  }, [product]);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("en-PH", {
      style: "currency",
      currency: "PHP",
    }).format(value);
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-PH", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  if (!product) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
      <div className="bg-white shadow-[-10px_-10px_30px_4px_rgba(0,0,0,0.1),_10px_10px_30px_4px_rgba(45,78,255,0.15)] rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-2xl font-bold text-gray-900">
              {product.product_name}
            </h2>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700 transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="aspect-square overflow-hidden rounded-lg">
                <img
                  src={product.image || "/placeholder.png"}
                  alt={product.product_name}
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = "/placeholder.png";
                  }}
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Brand</h3>
                  <p className="mt-1 text-sm text-gray-900">
                    {product.brand_name}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">
                    Category
                  </h3>
                  <p className="mt-1 text-sm text-gray-900">
                    {product.category}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Price</h3>
                  <p className="mt-1 text-lg font-semibold text-blue-600">
                    {formatCurrency(product.price)}
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">
                    Stock Status
                  </h3>
                  <p className="mt-1 text-sm">
                    {!currentBatch || currentBatch.quantity <= 0 ? (
                      <span className="text-red-600 font-medium">
                        Out of Stock
                      </span>
                    ) : currentBatch.is_low_stock ? (
                      <span className="text-yellow-600 font-medium">
                        Low Stock ({currentBatch.quantity} remaining)
                      </span>
                    ) : (
                      <span className="text-green-600 font-medium">
                        In Stock ({currentBatch.quantity} available)
                      </span>
                    )}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium text-gray-500">
                  Description
                </h3>
                <p className="mt-1 text-sm text-gray-900">
                  {product.description}
                </p>
              </div>

              {loading ? (
                <div className="text-sm text-gray-500">
                  Loading batch information...
                </div>
              ) : (
                <div>
                  <h3 className="text-sm font-medium text-gray-500">
                    Current Batch Details
                  </h3>
                  {currentBatch ? (
                    <div className="mt-1 space-y-1">
                      <p className="text-sm text-gray-900">
                        Expiration Date:{" "}
                        {formatDate(currentBatch.expiration_date)}
                      </p>
                      <p className="text-sm text-gray-900">
                        Batch Number: {currentBatch.batch_number}
                      </p>
                      <p className="text-sm text-gray-900">
                        Quantity: {currentBatch.quantity}
                      </p>
                    </div>
                  ) : (
                    <p className="text-sm text-red-600">
                      No active batches available
                    </p>
                  )}
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                {product.requires_prescription && (
                  <span className="inline-block px-2 py-1 text-xs font-semibold bg-yellow-100 text-yellow-700 rounded">
                    Requires Prescription
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailModal;
