import React, { useState, useEffect } from "react";
import axios from "axios";
import ProductModal from "./ProductModal";
import { toast } from "react-toastify";

export default function ProductManagement() {
  const [products, setProducts] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    id: null,
    product_name: "",
    brand_name: "",
    category: "",
    price: "",
    description: "", 
    requires_prescription: false,
    image: null, 
  });

  // Fetch all products from backend
  const fetchProducts = async () => {
    try {
      const response = await axios.get("http://127.0.0.1:8000/api/products/");
      setProducts(response.data);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const resetFormData = () => {
    setFormData({
      id: null,
      product_name: "",
      brand_name: "",
      category: "",
      price: "",
      description: "",
      requires_prescription: false,
      image: null,
    });
  };

  // Handle input changes from form
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
  
    if (type === "checkbox") {
      setFormData((prev) => ({
        ...prev,
        [name]: checked, 
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };
  
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData((prev) => ({
        ...prev,
        image: file,
      }));
    }
  };

  // Handle form submission (add or update)
  const handleFormSubmit = async (e) => {
    e.preventDefault();
    const formDataToSend = new FormData();
  
    for (const key in formData) {
      if (formData[key] !== null && formData[key] !== "") {
        formDataToSend.append(key, formData[key]);
      }
    }
  
    try {
      if (formData.id) {
        // Update existing product
        await axios.put(
          `http://127.0.0.1:8000/api/products/${formData.id}/`,
          formDataToSend,
          { headers: { "Content-Type": "multipart/form-data" } }
        );
        toast.success(`${formData.product_name} updated successfully.`);
      } else {
        // Add new product
        await axios.post(
          "http://127.0.0.1:8000/api/products/",
          formDataToSend,
          { headers: { "Content-Type": "multipart/form-data" } }
        );
        toast.success(`${formData.product_name} added successfully.`);
      }
  
      fetchProducts();
      resetFormData();
      setShowModal(false);
    } catch (error) {
      if (error.response && error.response.data) {
        const firstError = Object.values(error.response.data)[0];
        toast.error(Array.isArray(firstError) ? firstError[0] : firstError);
      } else {
        toast.error("An error occurred. Please try again.");
      }
    }
  };
  

  const handleEditClick = (product) => {
    setFormData({
      id: product.id,
      product_name: product.product_name,
      brand_name: product.brand_name,
      category: product.category,
      price: product.price,
      description: product.description || "", // Ensure description is populated
      requires_prescription: product.requires_prescription || false,
      image: null, // Reset image for editing
    });    
    setShowModal(true);
  };

  return (
    <div className="p-6 flex-1">
      {/* Title */}
      <div className="flex justify-between mb-6">
        <h1 className="text-3xl font-bold mb-4">Product Management</h1>
        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-700 text-white px-5 py-2.5 rounded-lg hover:bg-blue-800"
        >
          Add Product
        </button>
      </div>

      {/* Table */}
      <div className="bg-white shadow-[0_3px_10px_rgb(0,0,0,0.2)] rounded-lg p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Products</h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse rounded-lg">
            <thead>
              <tr className="bg-gray-200 text-gray-700">
                <th className="py-3 px-4 text-left">ID</th>
                <th className="py-3 px-4 text-left">Product Name</th>
                <th className="py-3 px-4 text-left">Brand</th>
                <th className="py-3 px-4 text-left">Category</th>
                <th className="py-3 px-4 text-left">Price</th>
                <th className="py-3 px-4 text-left">Prescription Status</th>
                <th className="py-3 px-4 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => (
                <tr key={product.id} className="border-t">
                  <td className="py-3 px-4">{product.id}</td>
                  <td className="py-3 px-4">{product.product_name}</td>
                  <td className="py-3 px-4">{product.brand_name}</td>
                  <td className="py-3 px-4">{product.category}</td>
                  <td className="py-3 px-4">
                    ₱{parseFloat(product.price).toFixed(2)}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-1 rounded-full text-sm font-semibold ${
                        product.requires_prescription
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-green-100 text-green-800"
                      }`}
                    >
                      {product.requires_prescription
                        ? "Required"
                        : "Not Required"}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <button
                      onClick={() => handleEditClick(product)}
                      className="bg-blue-500 text-white px-3 py-1 rounded-md hover:bg-blue-600"
                    >
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Product Modal */}
      <ProductModal
        showModal={showModal}
        setShowModal={setShowModal}
        formData={formData}
        handleInputChange={handleInputChange}
        handleImageChange={handleImageChange}
        handleFormSubmit={handleFormSubmit}
        resetFormData={resetFormData}
      />
    </div>
  );
}
