import React, { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import { FaEdit, FaPlus, FaSearch } from "react-icons/fa";
import PropTypes from "prop-types";

function InventoryModal({ product, onClose, refreshBatches }) {
  const [batches, setBatches] = useState([]);
  const [filteredBatches, setFilteredBatches] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBatch, setSelectedBatch] = useState(null);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Form states
  const [formData, setFormData] = useState({
    batch_code: "",
    quantity: 0,
    expiration_date: "",
    date_received: new Date().toISOString().split("T")[0],
    is_active: true,
  });

  const fetchBatchesForProduct = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await axios.get(
        `http://127.0.0.1:8000/api/product/${product.id}/batches/`
      );

      // Process batches to handle expired ones
      const processedBatches = await Promise.all(
        response.data.map(async (batch) => {
          if (batch.is_expired && batch.is_active) {
            try {
              // Create stock adjustment for expired batch
              await axios.post("http://127.0.0.1:8000/api/stock-adjustments/", {
                batch_id: batch.id,
                adjustment_type: "Expired",
                quantity: batch.quantity - batch.stock_out,
                reason: "Batch expired - automatic adjustment",
              });

              // Update batch to inactive
              await axios.put(
                `http://127.0.0.1:8000/api/batches/${batch.id}/`,
                {
                  ...batch,
                  is_active: false,
                  stock_out: batch.quantity, // Set stock_out to total quantity
                }
              );

              return {
                ...batch,
                is_active: false,
                stock_out: batch.quantity,
              };
            } catch (error) {
              console.error("Error processing expired batch:", error);
              return batch;
            }
          }
          return batch;
        })
      );

      setBatches(processedBatches);
    } catch (error) {
      console.error("Error fetching batches:", error);
      setError("Failed to fetch batches. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBatchesForProduct();
  }, [product]);

  useEffect(() => {
    // Filter batches based on search term
    const filtered = batches.filter((batch) => {
      const searchLower = searchTerm.toLowerCase();
      return (
        batch.batch_code.toLowerCase().includes(searchLower) ||
        batch.expiration_date.toLowerCase().includes(searchLower) ||
        (batch.is_expired && "expired".includes(searchLower)) ||
        (!batch.is_active && "inactive".includes(searchLower)) ||
        (batch.is_active && !batch.is_expired && "active".includes(searchLower))
      );
    });
    setFilteredBatches(filtered);
  }, [searchTerm, batches]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleAddBatch = async (e) => {
    e.preventDefault();
    try {
      const batchData = {
        ...formData,
        product_id: product.id,
        quantity: parseInt(formData.quantity),
      };

      await axios.post("http://127.0.0.1:8000/api/batches/", batchData);
      toast.success("Batch added successfully!");
      setAddModalOpen(false);
      resetFormData();
      fetchBatchesForProduct();
      refreshBatches?.();
    } catch (error) {
      console.error("Error adding batch:", error);
      toast.error(error.response?.data?.message || "Failed to add batch");
    }
  };

  const handleEditBatch = async (e) => {
    e.preventDefault();
    try {
      const updatedBatch = {
        ...formData,
        product_id: selectedBatch.product.id,
        quantity: parseInt(formData.quantity),
      };

      await axios.put(
        `http://127.0.0.1:8000/api/batches/${selectedBatch.id}/`,
        updatedBatch
      );

      toast.success("Batch updated successfully!");
      setEditModalOpen(false);
      setSelectedBatch(null);
      resetFormData();
      fetchBatchesForProduct();
      refreshBatches?.();
    } catch (error) {
      console.error("Error updating batch:", error);
      toast.error(error.response?.data?.message || "Failed to update batch");
    }
  };

  const resetFormData = () => {
    setFormData({
      batch_code: "",
      quantity: 0,
      expiration_date: "",
      date_received: new Date().toISOString().split("T")[0],
      is_active: true,
    });
  };

  const handleEdit = (batch) => {
    setSelectedBatch(batch);
    setFormData({
      batch_code: batch.batch_code,
      quantity: batch.quantity,
      expiration_date: batch.expiration_date,
      date_received: batch.date_received,
      is_active: batch.is_active,
    });
    setEditModalOpen(true);
  };

  if (loading) {
    return (
      <div className="fixed inset-0 flex justify-center items-center z-50 backdrop-blur-sm">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700"></div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 flex justify-center items-center z-50 backdrop-blur-sm">
      <div className="bg-white shadow-[-10px_-10px_30px_4px_rgba(0,0,0,0.1),_10px_10px_30px_4px_rgba(45,78,255,0.15)] rounded-lg p-6 w-3/4 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold text-gray-800">
            Batches - {product.product_name}
          </h2>
          <button
            onClick={() => setAddModalOpen(true)}
            className="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 flex items-center gap-2"
          >
            <FaPlus /> Add New Batch
          </button>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}

        {/* Search Bar */}
        <div className="mb-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Search by batch code, expiration date, or status..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full p-2 pl-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <FaSearch className="absolute left-3 top-3 text-gray-400" />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border border-gray-200 table-auto">
            <thead className="bg-gray-100 text-gray-700">
              <tr>
                <th className="px-4 py-2 text-left">Batch Code</th>
                <th className="px-4 py-2 text-left">Quantity</th>
                <th className="px-4 py-2 text-left">Stock Out</th>
                <th className="px-4 py-2 text-left">Available</th>
                <th className="px-4 py-2 text-left">Expiration Date</th>
                <th className="px-4 py-2 text-left">Status</th>
                <th className="px-4 py-2 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredBatches.length > 0 ? (
                filteredBatches.map((batch) => (
                  <tr
                    key={batch.id}
                    className="border-t text-gray-700 hover:bg-gray-50"
                  >
                    <td className="px-4 py-2">{batch.batch_code}</td>
                    <td className="px-4 py-2">{batch.quantity}</td>
                    <td className="px-4 py-2">{batch.stock_out}</td>
                    <td className="px-4 py-2">
                      {batch.quantity - batch.stock_out}
                    </td>
                    <td className="px-4 py-2">
                      {new Date(batch.expiration_date).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-2">
                      <span
                        className={`px-2 py-1 rounded-full text-xs font-semibold ${
                          batch.is_expired
                            ? "bg-red-100 text-red-800"
                            : !batch.is_active
                            ? "bg-gray-100 text-gray-800"
                            : "bg-green-100 text-green-800"
                        }`}
                      >
                        {batch.is_expired
                          ? "Expired"
                          : !batch.is_active
                          ? "Inactive"
                          : "Active"}
                      </span>
                    </td>
                    <td className="px-4 py-2">
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEdit(batch)}
                          className="bg-blue-500 text-white px-3 py-1 rounded-md hover:bg-blue-600 flex items-center gap-1"
                        >
                          <FaEdit /> Edit
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan={7}
                    className="px-4 py-2 text-center text-gray-500"
                  >
                    {searchTerm
                      ? "No batches match your search."
                      : "No batches found for this product."}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex justify-end mt-6">
          <button
            onClick={onClose}
            className="bg-gray-500 text-white px-6 py-2 rounded-md font-medium hover:bg-gray-600"
          >
            Close
          </button>
        </div>

        {/* Add Batch Modal */}
        {addModalOpen && (
          <div className="fixed inset-0 flex justify-center items-center z-50 backdrop-blur-sm">
            <div className="bg-white shadow-lg rounded-lg p-6 w-1/3">
              <h2 className="text-2xl font-bold mb-4 text-gray-800">
                Add New Batch
              </h2>
              <form onSubmit={handleAddBatch}>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Batch Code
                  </label>
                  <input
                    type="text"
                    name="batch_code"
                    value={formData.batch_code}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Quantity
                  </label>
                  <input
                    type="number"
                    name="quantity"
                    value={formData.quantity}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    min="0"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Date Received
                  </label>
                  <input
                    type="date"
                    name="date_received"
                    value={formData.date_received}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Expiration Date
                  </label>
                  <input
                    type="date"
                    name="expiration_date"
                    value={formData.expiration_date}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>

                <div className="flex justify-between mt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setAddModalOpen(false);
                      resetFormData();
                    }}
                    className="bg-gray-500 text-white px-6 py-2 rounded-md font-medium hover:bg-gray-600"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-green-500 text-white px-6 py-2 rounded-md font-medium hover:bg-green-600"
                  >
                    Add Batch
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Edit Batch Modal */}
        {editModalOpen && selectedBatch && (
          <div className="fixed inset-0 flex justify-center items-center z-50 backdrop-blur-sm">
            <div className="bg-white shadow-lg rounded-lg p-6 w-1/3">
              <h2 className="text-2xl font-bold mb-4 text-gray-800">
                Edit Batch - {selectedBatch.batch_code}
              </h2>
              <form onSubmit={handleEditBatch}>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Batch Code
                  </label>
                  <input
                    type="text"
                    name="batch_code"
                    value={formData.batch_code}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Quantity
                  </label>
                  <input
                    type="number"
                    name="quantity"
                    value={formData.quantity}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    min="0"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Date Received
                  </label>
                  <input
                    type="date"
                    name="date_received"
                    value={formData.date_received}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Expiration Date
                  </label>
                  <input
                    type="date"
                    name="expiration_date"
                    value={formData.expiration_date}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Status
                  </label>
                  <select
                    name="is_active"
                    value={formData.is_active}
                    onChange={handleInputChange}
                    className="w-full p-2 border border-gray-300 rounded-md"
                  >
                    <option value={true}>Active</option>
                    <option value={false}>Inactive</option>
                  </select>
                </div>

                <div className="flex justify-between mt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setEditModalOpen(false);
                      setSelectedBatch(null);
                      resetFormData();
                    }}
                    className="bg-gray-500 text-white px-6 py-2 rounded-md font-medium hover:bg-gray-600"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-blue-500 text-white px-6 py-2 rounded-md font-medium hover:bg-blue-600"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

InventoryModal.propTypes = {
  product: PropTypes.shape({
    id: PropTypes.number.isRequired,
    product_name: PropTypes.string.isRequired,
  }).isRequired,
  onClose: PropTypes.func.isRequired,
  refreshBatches: PropTypes.func,
};

export default InventoryModal;
