import React, { useState } from "react";
import { X, Plus, Minus, ShoppingCart, FileText } from "lucide-react";
import PropTypes from "prop-types";
import PrescriptionUpload from "./PrescriptionUpload";

const ProductDetailModal = ({
  isOpen,
  onClose,
  product,
  onAddToCart,
  onPrescriptionUpload,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [showPrescriptionUpload, setShowPrescriptionUpload] = useState(false);

  if (!isOpen) return null;

  const formatPrice = (price) => {
    return new Intl.NumberFormat("en-PH", {
      style: "currency",
      currency: "PHP",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  const handleQuantityChange = (newQuantity) => {
    if (newQuantity >= 1) {
      setQuantity(newQuantity);
    }
  };

  const handleAddToCart = () => {
    onAddToCart(product, quantity);
    onClose();
  };

  const handlePrescriptionUpload = () => {
    setShowPrescriptionUpload(true);
  };

  return (
    <>
      <div className="fixed inset-0 bg-black/60 flex justify-center items-center z-50">
        <div className="bg-white w-full max-w-2xl rounded-xl shadow-lg">
          {/* Header */}
          <div className="p-4 border-b flex justify-between items-center">
            <h2 className="text-xl font-bold">Product Details</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <X size={24} />
            </button>
          </div>

          <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Product Image */}
              <div className="relative h-64 bg-gray-100 rounded-lg overflow-hidden">
                {product.image ? (
                  <img
                    src={product.image}
                    alt={product.product_name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-400">
                    No Image Available
                  </div>
                )}
              </div>

              {/* Product Info */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-2xl font-bold">{product.product_name}</h3>
                  <p className="text-gray-600">{product.brand_name}</p>
                </div>

                <div className="text-2xl font-bold text-teal-600">
                  {formatPrice(product.price)}
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Description</h4>
                  <p className="text-gray-600">{product.description}</p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Category</h4>
                  <p className="text-gray-600">{product.category}</p>
                </div>

                {product.requires_prescription && (
                  <div className="bg-yellow-50 p-3 rounded-lg text-yellow-800">
                    <p className="flex items-center gap-2">
                      <FileText size={20} />
                      This product requires a prescription
                    </p>
                  </div>
                )}

                {/* Quantity and Add to Cart */}
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <label className="font-semibold">Quantity:</label>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleQuantityChange(quantity - 1)}
                        className="p-1 hover:bg-gray-200 rounded bg-gray-100"
                        disabled={quantity <= 1}
                      >
                        <Minus size={16} />
                      </button>
                      <span className="w-8 text-center">{quantity}</span>
                      <button
                        onClick={() => handleQuantityChange(quantity + 1)}
                        className="p-1 hover:bg-gray-200 rounded bg-gray-100"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  </div>

                  {product.requires_prescription ? (
                    <button
                      onClick={handlePrescriptionUpload}
                      className="w-full bg-teal-600 text-white py-3 rounded-lg font-semibold hover:bg-teal-700 shadow-md flex items-center justify-center gap-2"
                    >
                      <FileText size={20} />
                      Upload Prescription
                    </button>
                  ) : (
                    <button
                      onClick={handleAddToCart}
                      className="w-full bg-teal-600 text-white py-3 rounded-lg font-semibold hover:bg-teal-700 shadow-md flex items-center justify-center gap-2"
                    >
                      <ShoppingCart size={20} />
                      Add to Cart
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Prescription Upload Modal */}
      {showPrescriptionUpload && (
        <PrescriptionUpload
          isOpen={showPrescriptionUpload}
          onClose={() => setShowPrescriptionUpload(false)}
          product={product}
          onUploadSuccess={onPrescriptionUpload}
        />
      )}
    </>
  );
};

ProductDetailModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  product: PropTypes.shape({
    id: PropTypes.number.isRequired,
    product_name: PropTypes.string.isRequired,
    brand_name: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    description: PropTypes.string,
    category: PropTypes.string.isRequired,
    image: PropTypes.string,
    requires_prescription: PropTypes.bool.isRequired,
  }).isRequired,
  onAddToCart: PropTypes.func.isRequired,
  onPrescriptionUpload: PropTypes.func.isRequired,
};

export default ProductDetailModal;
