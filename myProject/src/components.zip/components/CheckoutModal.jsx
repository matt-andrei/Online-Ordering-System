import React, { useState } from "react";
import { X } from "lucide-react";
import PropTypes from "prop-types";

const CheckoutModal = ({ isOpen, onClose, cartItems, onPlaceOrder }) => {
  const [formData, setFormData] = useState({
    pickupDate: "",
    notes: "",
  });

  if (!isOpen) return null;

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const calculateTotal = () => {
    return cartItems.reduce(
      (total, item) => total + item.price * item.quantity,
      0
    );
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat("en-PH", {
      style: "currency",
      currency: "PHP",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onPlaceOrder({
      ...formData,
      items: cartItems,
      total: calculateTotal(),
    });
  };

  // Get minimum date (tomorrow)
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const minDate = tomorrow.toISOString().split("T")[0];

  return (
    <div className="fixed inset-0 bg-black/60 flex justify-center items-center z-50">
      <div className="bg-white w-full max-w-2xl rounded-xl shadow-lg flex flex-col max-h-[90vh]">
        {/* Header - Fixed */}
        <div className="p-4 border-b flex justify-between items-center flex-shrink-0">
          <h2 className="text-xl font-bold">Checkout</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <X size={24} />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto">
          <form onSubmit={handleSubmit} className="p-4">
            {/* Order Summary */}
            <div className="mb-6">
              <h3 className="font-semibold mb-2">Order Summary</h3>
              <div className="bg-gray-50 rounded-lg p-4">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex justify-between py-2">
                    <span>
                      {item.product_name} x {item.quantity}
                    </span>
                    <span className="text-teal-600">
                      {formatPrice(item.price * item.quantity)}
                    </span>
                  </div>
                ))}
                <div className="border-t mt-2 pt-2 flex justify-between font-bold">
                  <span>Total</span>
                  <span className="text-teal-600">
                    {formatPrice(calculateTotal())}
                  </span>
                </div>
              </div>
            </div>

            {/* Pickup Information */}
            <div className="space-y-4">
              <h3 className="font-semibold">Pickup Information</h3>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Pickup Date
                </label>
                <input
                  type="date"
                  name="pickupDate"
                  value={formData.pickupDate}
                  onChange={handleInputChange}
                  min={minDate}
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
                  required
                />
                <p className="text-sm text-gray-500 mt-1">
                  Please select a date at least one day in advance
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Additional Notes (Optional)
                </label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
                  rows="2"
                  placeholder="Any special instructions or requests"
                />
              </div>
            </div>
          </form>
        </div>

        {/* Footer - Fixed */}
        <div className="border-t p-4 flex-shrink-0">
          <button
            type="submit"
            onClick={handleSubmit}
            className="w-full bg-teal-600 text-white py-3 rounded-lg font-semibold hover:bg-teal-700 shadow-md"
          >
            Place Order
          </button>
        </div>
      </div>
    </div>
  );
};

CheckoutModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  cartItems: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      product_name: PropTypes.string.isRequired,
      price: PropTypes.number.isRequired,
      quantity: PropTypes.number.isRequired,
    })
  ).isRequired,
  onPlaceOrder: PropTypes.func.isRequired,
};

export default CheckoutModal;
