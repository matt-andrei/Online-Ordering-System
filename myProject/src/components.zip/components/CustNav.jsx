import React, { useState, useEffect } from "react";
import {
  Home,
  Menu,
  Search,
  ShoppingCart,
  User,
  X,
  LogOut,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import axios from "axios";

const SettingsModal = ({ onClose }) => (
  <div
    className="fixed top-0 left-0 w-full h-full bg-black/60 flex justify-center items-center z-50"
    onClick={onClose}
  >
    <div
      className="bg-white p-5 w-[90%] max-w-[400px] rounded-xl relative shadow-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <button
        className="absolute top-2.5 right-4 bg-transparent border-none text-lg cursor-pointer"
        onClick={onClose}
      >
        <X size={24} />
      </button>
      <h2 className="text-2xl font-bold mb-4">Settings</h2>
      <p className="text-gray-600">Settings coming soon!</p>
    </div>
  </div>
);

const HelpSupportModal = ({ onClose }) => (
  <div
    className="fixed top-0 left-0 w-full h-full bg-black/60 flex justify-center items-center z-50"
    onClick={onClose}
  >
    <div
      className="bg-white p-5 w-[90%] max-w-[400px] rounded-xl relative shadow-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <button
        className="absolute top-2.5 right-4 bg-transparent border-none text-lg cursor-pointer"
        onClick={onClose}
      >
        <X size={24} />
      </button>
      <h2 className="text-2xl font-bold mb-4">Help & Support</h2>
      <p className="text-gray-600 mb-2">For support, contact us at:</p>
      <p className="text-primary font-semibold">support@example.com</p>
      <p className="text-gray-500 text-sm mt-4">
        FAQ and more help coming soon!
      </p>
    </div>
  </div>
);

const LogoutConfirmationModal = ({ onClose, onConfirm }) => (
  <div
    className="fixed top-0 left-0 w-full h-full bg-black/60 flex justify-center items-center z-50"
    onClick={onClose}
  >
    <div
      className="bg-white p-5 w-[90%] max-w-[400px] rounded-xl relative shadow-lg"
      onClick={(e) => e.stopPropagation()}
    >
      <button
        className="absolute top-2.5 right-4 bg-transparent border-none text-lg cursor-pointer"
        onClick={onClose}
      >
        <X size={24} />
      </button>
      <h2 className="text-2xl font-bold mb-4">Confirm Logout</h2>
      <p className="text-gray-600 mb-6">Are you sure you want to logout?</p>
      <div className="flex justify-end gap-4">
        <button
          className="px-4 py-2 text-gray-600 hover:text-gray-800"
          onClick={onClose}
        >
          Cancel
        </button>
        <button
          className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
          onClick={onConfirm}
        >
          Logout
        </button>
      </div>
    </div>
  </div>
);

const ProfileModal = ({
  onClose,
  onEditProfile,
  onOpenSettings,
  onOpenHelp,
}) => {
  const { user } = useAuth();
  const [userInfo, setUserInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUserInfo = async () => {
      if (!user || !user.id) {
        setError("User not logged in");
        setLoading(false);
        return;
      }

      try {
        const response = await axios.get(
          `http://localhost:8000/api/users/${user.id}/`,
          {
            headers: {
              Authorization: `Bearer ${user.accessToken}`,
            },
          }
        );
        setUserInfo(response.data);
        setError(null);
      } catch (error) {
        console.error("Error fetching user info:", error);
        setError(
          error.response?.data?.message || "Failed to load user information"
        );
      } finally {
        setLoading(false);
      }
    };

    fetchUserInfo();
  }, [user]);

  return (
    <div
      className="fixed top-0 left-0 w-full h-full bg-black/60 flex justify-center items-center z-50"
      onClick={onClose}
    >
      <div
        className="bg-white p-5 w-[90%] max-w-[500px] rounded-xl relative shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          className="absolute top-2.5 right-4 bg-transparent border-none text-lg cursor-pointer"
          onClick={onClose}
        >
          <X size={24} />
        </button>
        <div className="p-4">
          <div className="flex flex-col items-center gap-2 mb-4">
            <User size={48} />
            <h2 className="text-2xl font-bold">My Profile</h2>
          </div>
          <div className="mb-4">
            <h3 className="text-lg font-semibold mb-2">Personal Information</h3>
            {loading ? (
              <div className="text-center py-4">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-teal-600 mx-auto"></div>
                <p className="mt-2 text-gray-600">Loading profile...</p>
              </div>
            ) : error ? (
              <div className="text-center py-4">
                <p className="text-red-600">{error}</p>
                <button
                  onClick={() => (window.location.href = "/login")}
                  className="mt-2 text-teal-600 hover:text-teal-700"
                >
                  Go to Login
                </button>
              </div>
            ) : userInfo ? (
              <>
                <div className="flex justify-between py-2 border-b">
                  <span className="text-gray-600">Name:</span>
                  <span>
                    {userInfo.first_name} {userInfo.last_name}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b">
                  <span className="text-gray-600">Username:</span>
                  <span>{userInfo.username}</span>
                </div>
                <div className="flex justify-between py-2 border-b">
                  <span className="text-gray-600">Phone:</span>
                  <span>{userInfo.phone || "Not set"}</span>
                </div>
                <div className="flex justify-between py-2 border-b">
                  <span className="text-gray-600">Address:</span>
                  <span>{userInfo.address || "Not set"}</span>
                </div>
                <div className="flex justify-between py-2 border-b">
                  <span className="text-gray-600">Birth Date:</span>
                  <span>{userInfo.birthdate || "Not set"}</span>
                </div>
              </>
            ) : (
              <div className="text-center py-4 text-red-600">
                Failed to load profile information
              </div>
            )}
          </div>
          {!error && (
            <div className="flex flex-col gap-2">
              <button
                className="flex items-center gap-2 px-4 py-2.5 border-none rounded-full bg-primary text-white font-medium cursor-pointer transition-all duration-200 hover:bg-primary-dark hover:-translate-y-0.5"
                onClick={onEditProfile}
              >
                Edit Profile
              </button>
              <button
                className="flex items-center gap-2 px-4 py-2.5 border-none rounded-full bg-primary text-white font-medium cursor-pointer transition-all duration-200 hover:bg-primary-dark hover:-translate-y-0.5"
                onClick={onOpenSettings}
              >
                Settings
              </button>
              <button
                className="flex items-center gap-2 px-4 py-2.5 border-none rounded-full bg-primary text-white font-medium cursor-pointer transition-all duration-200 hover:bg-primary-dark hover:-translate-y-0.5"
                onClick={onOpenHelp}
              >
                Help & Support
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const CustNav = ({
  currentSection,
  onNavigate,
  setSearch,
  onToggleCart,
  cartItemsCount,
  onEditProfile,
  cartIconRef,
}) => {
  const [showProfile, setShowProfile] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const { logout } = useAuth();

  // Openers for child modals
  const handleOpenEditProfile = () => {
    setShowProfile(false);
    onEditProfile();
  };
  const handleOpenSettings = () => {
    setShowProfile(false);
    setShowSettings(true);
  };
  const handleOpenHelp = () => {
    setShowProfile(false);
    setShowHelp(true);
  };
  const handleLogout = () => {
    setShowProfile(false);
    setShowLogoutConfirm(true);
  };
  const handleConfirmLogout = () => {
    logout();
    setShowLogoutConfirm(false);
  };

  // Closers for child modals
  const handleCloseSettings = () => {
    setShowSettings(false);
    setShowProfile(true);
  };
  const handleCloseHelp = () => {
    setShowHelp(false);
    setShowProfile(true);
  };

  return (
    <>
      {/* Top Navigation */}
      <div className="fixed top-0 left-0 w-full bg-white z-50 py-2.5 px-5 shadow-sm flex justify-between items-center">
        <button
          className="bg-transparent border-none cursor-pointer p-2 rounded-full transition-all duration-200 flex items-center hover:bg-gray-100"
          onClick={() => setShowProfile(true)}
        >
          <User />
        </button>

        <div className="flex items-center flex-1 bg-secondary rounded-full px-3 py-1 mx-2">
          <input
            type="text"
            placeholder="Search Product..."
            className="border-none bg-transparent p-2 outline-none w-full"
            onChange={(e) => setSearch(e.target.value)}
          />
          <button className="bg-transparent border-none cursor-pointer p-1">
            <Search />
          </button>
        </div>

        <button
          className="p-2 relative"
          onClick={onToggleCart}
          ref={cartIconRef}
        >
          <ShoppingCart />
          {cartItemsCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-primary text-white text-xs min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center font-semibold">
              {cartItemsCount}
            </span>
          )}
        </button>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 w-full bg-white shadow-md flex justify-around items-center p-2">
        <button
          className={`flex flex-col items-center gap-1 text-gray-600 cursor-pointer transition-colors duration-200 ${
            currentSection === "home" ? "text-primary" : ""
          }`}
          onClick={() => onNavigate("home")}
        >
          <Home color={currentSection === "home" ? "#00BFA6" : "#666"} />
          <span>Home</span>
        </button>
        <button
          className={`flex flex-col items-center gap-1 text-gray-600 cursor-pointer transition-colors duration-200 ${
            currentSection === "categories" ? "text-primary" : ""
          }`}
          onClick={() => onNavigate("categories")}
        >
          <Menu color={currentSection === "categories" ? "#00BFA6" : "#666"} />
          <span>Categories</span>
        </button>
      </div>

      {/* Modals */}
      {showProfile && (
        <ProfileModal
          onClose={() => setShowProfile(false)}
          onEditProfile={handleOpenEditProfile}
          onOpenSettings={handleOpenSettings}
          onOpenHelp={handleOpenHelp}
        />
      )}
      {showSettings && <SettingsModal onClose={handleCloseSettings} />}
      {showHelp && <HelpSupportModal onClose={handleCloseHelp} />}
      {showLogoutConfirm && (
        <LogoutConfirmationModal
          onClose={() => setShowLogoutConfirm(false)}
          onConfirm={handleConfirmLogout}
        />
      )}
    </>
  );
};

export default CustNav;
