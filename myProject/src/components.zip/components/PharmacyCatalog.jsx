import { useState, useRef, useEffect } from "react";
import PropTypes from "prop-types";
import CustNav from "./CustNav";
import axios from "axios";
import CartModal from "./CartModal";
import CheckoutModal from "./CheckoutModal";
import EditProfile from "./EditProfile";
import ProductDetailModal from "./ProductDetailModal";
import { toast } from "react-toastify";

// Format price to Philippine Peso - moved outside components to be accessible to both
const formatPrice = (price) => {
  return new Intl.NumberFormat("en-PH", {
    style: "currency",
    currency: "PHP",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(price);
};

const ProductCard = ({ product, onAddToCart }) => {
  const [imageError, setImageError] = useState(false);
  const [imageLoading, setImageLoading] = useState(true);

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="relative h-48 bg-gray-100">
        {product.image && !imageError ? (
          <>
            {imageLoading && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-teal-600"></div>
              </div>
            )}
            <img
              src={product.image}
              alt={product.product_name}
              className={`w-full h-full object-cover ${
                imageLoading ? "opacity-0" : "opacity-100"
              } transition-opacity duration-300`}
              onLoad={() => setImageLoading(false)}
              onError={() => {
                setImageError(true);
                setImageLoading(false);
              }}
            />
          </>
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gray-100">
            <span className="text-gray-400">No Image Available</span>
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-2">{product.product_name}</h3>
        <p className="text-gray-600 text-sm mb-2">{product.brand_name}</p>
        <div className="flex justify-between items-center">
          <span className="text-teal-600 font-bold">
            {formatPrice(product.price)}
          </span>
          <button
            className="bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 transition-colors duration-200 shadow-md"
            onClick={onAddToCart}
          >
            View Details
          </button>
        </div>
        {product.requires_prescription && (
          <p className="text-red-500 text-sm mt-2">Prescription Required</p>
        )}
      </div>
    </div>
  );
};

// Add PropTypes validation for ProductCard
ProductCard.propTypes = {
  product: PropTypes.shape({
    id: PropTypes.number.isRequired,
    product_name: PropTypes.string.isRequired,
    brand_name: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    image: PropTypes.string,
    requires_prescription: PropTypes.bool,
  }).isRequired,
  onAddToCart: PropTypes.func.isRequired,
};

const PharmacyCatalog = () => {
  const [currentSection, setCurrentSection] = useState("home");
  const [searchQuery, setSearchQuery] = useState("");
  const [cartItemsCount, setCartItemsCount] = useState(0);
  const [products, setProducts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const cartIconRef = useRef(null);

  // Modal states
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isProductDetailOpen, setIsProductDetailOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [cartItems, setCartItems] = useState([]);
  const [outOfStockItems, setOutOfStockItems] = useState([]);

  // Fetch products from backend
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get("http://localhost:8000/api/products/");
        // Transform the products to include full image URLs
        const productsWithFullUrls = response.data.map((product) => ({
          ...product,
          // Only prepend the base URL if the image path doesn't already start with http
          image: product.image
            ? product.image.startsWith("http")
              ? product.image
              : `http://localhost:8000${product.image}`
            : null,
        }));
        setProducts(productsWithFullUrls);
        setLoading(false);
      } catch (err) {
        setError("Failed to fetch products");
        setLoading(false);
        console.error("Error fetching products:", err);
      }
    };

    fetchProducts();
  }, []);

  const handleNavigate = (section) => {
    setCurrentSection(section);
  };

  const handleToggleCart = () => {
    setIsCartOpen(true);
  };

  const handleEditProfile = () => {
    setIsEditProfileOpen(true);
  };

  const handleCategoryChange = (e) => {
    setSelectedCategory(e.target.value);
  };

  const handleAddToCart = (product, quantity = 1) => {
    setCartItems((prevItems) => {
      const existingItem = prevItems.find((item) => item.id === product.id);
      if (existingItem) {
        return prevItems.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prevItems, { ...product, quantity }];
    });
    setCartItemsCount((prev) => prev + quantity);
  };

  const handleUpdateQuantity = (productId, newQuantity) => {
    setCartItems((prevItems) =>
      prevItems.map((item) =>
        item.id === productId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const handleRemoveItem = (productId) => {
    setCartItems((prevItems) => {
      const item = prevItems.find((item) => item.id === productId);
      setCartItemsCount((prev) => prev - item.quantity);
      return prevItems.filter((item) => item.id !== productId);
    });
  };

  const handleCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  // Helper to get FEFO batch for a product
  const getFEFOBatch = async (productId, quantityNeeded) => {
    try {
      const response = await axios.get(
        `http://localhost:8000/api/product/${productId}/batches/`
      );
      // Filter for active, non-expired batches with enough stock
      const validBatches = response.data
        .filter(
          (batch) =>
            batch.is_active &&
            !batch.is_expired &&
            batch.quantity - batch.stock_out >= quantityNeeded
        )
        .sort(
          (a, b) => new Date(a.expiration_date) - new Date(b.expiration_date)
        );
      return validBatches.length > 0 ? validBatches[0] : null;
    } catch {
      return null;
    }
  };

  const handlePlaceOrder = async (orderData) => {
    // Check stock for all items before placing order
    try {
      const batchResults = await Promise.all(
        cartItems.map(async (item) => {
          const batch = await getFEFOBatch(item.id, item.quantity);
          return { item, batch };
        })
      );

      const outOfStock = batchResults.filter((res) => !res.batch);
      if (outOfStock.length > 0) {
        setOutOfStockItems(outOfStock.map((res) => res.item.product_name));
        toast.error(
          `Not enough stock for: ${outOfStock
            .map((res) => res.item.product_name)
            .join(", ")}`
        );
        return;
      } else {
        setOutOfStockItems([]);
      }

      // All items have stock, proceed to place order
      const itemsWithBatch = batchResults.map((res) => ({
        batch: res.batch.id,
        quantity: res.item.quantity,
        price_at_time: res.item.price,
      }));

      const payload = {
        pickup_date: orderData.pickupDate,
        notes: orderData.notes || "",
        items: itemsWithBatch,
      };

      console.log("Order payload:", payload);
      const response = await axios.post(
        "http://localhost:8000/api/orders/",
        payload
      );
      console.log("Order response:", response.data);
      toast.success("Order placed successfully!");
      setIsCheckoutOpen(false);
      setCartItems([]);
      setCartItemsCount(0);
    } catch (err) {
      console.error("Order error details:", {
        message: err.message,
        response: err.response?.data,
        status: err.response?.status,
      });
      toast.error(
        err.message ||
          err.response?.data?.message ||
          "Failed to place order. Please try again."
      );
    }
  };

  const handlePrescriptionUpload = (prescriptionData) => {
    // Handle prescription upload success
    console.log("Prescription uploaded:", prescriptionData);
  };

  const handleProductClick = (product) => {
    setSelectedProduct(product);
    setIsProductDetailOpen(true);
  };

  // Filter products based on search query and selected category
  const filteredProducts = products.filter((product) => {
    const matchSearch = product.product_name
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    const matchCategory =
      selectedCategory === "All" || product.category === selectedCategory;
    return matchSearch && matchCategory;
  });

  // Get unique categories from products
  const categories = ["All", ...new Set(products.map((p) => p.category))];

  return (
    <div className="min-h-screen bg-gray-50">
      <CustNav
        currentSection={currentSection}
        onNavigate={handleNavigate}
        setSearch={setSearchQuery}
        onToggleCart={handleToggleCart}
        cartItemsCount={cartItemsCount}
        onEditProfile={handleEditProfile}
        cartIconRef={cartIconRef}
      />
      <div className="pt-16 pb-16">
        {" "}
        {/* Add padding to account for fixed navbars */}
        <div className="container mx-auto px-4">
          <div className="catalog-controls mb-6">
            <select
              className="w-full md:w-48 p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
              value={selectedCategory}
              onChange={handleCategoryChange}
            >
              {categories.map((category, idx) => (
                <option key={idx} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>

          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600 mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading products...</p>
            </div>
          ) : error ? (
            <div className="text-center py-8 text-red-600">
              <p>{error}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={() => handleProductClick(product)}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <CartModal
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckout={handleCheckout}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cartItems}
        onPlaceOrder={handlePlaceOrder}
      />

      <EditProfile
        isOpen={isEditProfileOpen}
        onClose={() => setIsEditProfileOpen(false)}
      />

      {selectedProduct && (
        <ProductDetailModal
          isOpen={isProductDetailOpen}
          onClose={() => {
            setIsProductDetailOpen(false);
            setSelectedProduct(null);
          }}
          product={selectedProduct}
          onAddToCart={handleAddToCart}
          onPrescriptionUpload={handlePrescriptionUpload}
        />
      )}

      {outOfStockItems.length > 0 && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 bg-red-100 border border-red-400 text-red-700 px-6 py-4 rounded shadow-lg">
          <b>Out of Stock:</b> {outOfStockItems.join(", ")}
        </div>
      )}
    </div>
  );
};

export default PharmacyCatalog;
