import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import image from "../assets/la-plaza.png";
import {
  FaChartBar,
  FaUsers,
  FaBoxOpen,
  FaChartLine,
} from "react-icons/fa";
import InventoryDropdown from "./InventoryDropdown";
import OrderDropdown from "./OrderDropdown";

export default function NavBar() {
  const { logout } = useAuth();

  return (
    <div className="h-screen w-64 bg-gray-100 p-5 flex flex-col fixed left-0 top-0 overflow-y-auto p-6">
      {/* Logo and Title */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center flex-shrink-0">
          <img
            src={image}
            alt="La-Plaza Pharmacy Logo"
            className="w-full h-full object-cover rounded-full"
          />
        </div>
        <span className="text-sm font-bold text-gray-800 leading-tight">
          Online Ordering System
        </span>
      </div>

      {/* Navigation Links */}
      <div className="flex flex-col gap-y-3 text-gray-700 flex-grow">
        <Link
          to="/dashboard"
          className="p-2 rounded hover:bg-gray-200 flex items-center gap-x-2"
        >
          <FaChartBar /> <span>Dashboard</span>
        </Link>
        <Link
          to="/user"
          className="p-2 rounded hover:bg-gray-200 flex items-center gap-x-2"
        >
          <FaUsers /> <span>User Management</span>
        </Link>

        <OrderDropdown />

        <Link
          to="/product"
          className="p-2 rounded hover:bg-gray-200 flex items-center gap-x-2"
        >
          <FaBoxOpen /> <span>Product Management</span>
        </Link>

        <InventoryDropdown />

        <Link
          to="/reports"
          className="p-2 rounded hover:bg-gray-200 flex items-center gap-x-2"
        >
          <FaChartLine /> <span>Reports</span>
        </Link>
      </div>

      {/* Logout */}
      <div className="mt-auto">
        <span className="font-semibold text-gray-500 text-sm">Settings</span>
        <button
          onClick={logout}
          className="w-full text-left p-2 text-red-600 font-semibold hover:bg-gray-200 rounded"
        >
          Logout
        </button>
      </div>
    </div>
  );
}
